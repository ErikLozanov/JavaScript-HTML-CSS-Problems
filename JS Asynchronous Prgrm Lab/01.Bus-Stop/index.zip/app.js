function getInfo() {
    
    let stopId = document.getElementById('stopId').value;
    let stopName = document.getElementById('stopName');
    let busUl = document.getElementById('buses');
    let url = `http://localhost:3030/jsonstore/bus/businfo/${stopId}`;

    fetch(url)
    .then(response => {
        if(response.status !== 200) {
            return Promise.reject('Error');
        }
            return response.json();
    })
    .then(data => {
        console.log(data);
        stopName.textContent = data.name;
        for(let el of Object.entries(data.buses)) {
            let li = document.createElement('li');
            li.textContent = `Bus ${el[0]} arrives in ${el[1]} minutes`;
            busUl.appendChild(li);
        }
    })
    .catch(error => stopName.textContent = error)
}